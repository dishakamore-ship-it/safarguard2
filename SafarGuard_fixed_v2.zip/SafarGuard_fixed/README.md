# SafarGuard — AI Driver Drowsiness Analyzer

## Run on Windows
1. Extract this ZIP and open the folder in VS Code.
2. In the terminal run:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   py -m pip install -r requirements.txt
   py app.py
   ```
3. Open http://127.0.0.1:5000 in Edge or Chrome. Do not open `index.html` directly and do not use Live Server for the full app; Flask serves the frontend and `/api` backend together.

## Features
- Camera preview + MediaPipe face mesh / EAR drowsiness monitoring.
- Start/stop monitoring and alert sound.
- Session history, weekly session/event analytics and CSV report export.
- Profile details saved locally in the browser; alert preference saved locally.
- User-started live location, coordinates, accuracy, update time and Google Maps link.
- Contact form API and SQLite storage.

Camera and location require browser permission. Geolocation requires localhost or HTTPS. Face mesh assets load from jsDelivr, so internet access is needed. Profile details are browser-local and are not an account/login system. This is a student demo and not a substitute for safe driving practices.
